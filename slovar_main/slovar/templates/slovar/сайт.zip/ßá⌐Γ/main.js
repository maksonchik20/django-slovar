$(".burger-menu").click(function(){
	$(".burger-menu__block").toggle(500);
  });